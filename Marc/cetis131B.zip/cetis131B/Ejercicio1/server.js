// server.js
const express = require('express');
const { MongoClient } = require('mongodb');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Reemplaza 'YOUR_CONNECTION_STRING_HERE' por el connection string de tu cluster
const uri = "mongodb+srv://MarcLazaro:a23328061310732@practica1.i925j.mongodb.net/?retryWrites=true&w=majority&appName=Practica1";

// Nota: En producción, es mejor mantener una única conexión en lugar de conectarse y desconectarse en cada petición.
let client;

// Middleware
app.use(bodyParser.json());
// Servir archivos estáticos desde la carpeta "public"
app.use(express.static('PUBLIC'));

// Ruta para insertar datos (por ejemplo, un usuario)
app.post('/insertar', async (req, res) => {
  try {
    client = new MongoClient(uri);
    await client.connect();
    const database = client.db("Ejercicio1");
    const collection = database.collection("Usuarios");
    
    const nuevoUsuario = req.body; // { nombre: "Ejemplo", edad: 25 }
    const result = await collection.insertOne(nuevoUsuario);
    res.send({ mensaje: "Usuario insertado", id: result.insertedId });
  } catch (error) {
    res.status(500).send({ error: error.message });
  } finally {
    await client.close();
  }
});

// Ruta para obtener datos procesados (ejemplo: promedio de edades)
app.get('/procesados', async (req, res) => {
  try {
    client = new MongoClient(uri);
    await client.connect();
    const database = client.db("Ejercicio1");
    const collection = database.collection("Usuarios");

    // Ejemplo: calcular el promedio de la edad de todos los usuarios
    const resultado = await collection.aggregate([
      {
        $group: {
          _id: null,
          promedioEdad: { $avg: "$edad" }
        }
      }
    ]).toArray();

    res.send(resultado);
  } catch (error) {
    res.status(500).send({ error: error.message });
  } finally {
    await client.close();
  }
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
